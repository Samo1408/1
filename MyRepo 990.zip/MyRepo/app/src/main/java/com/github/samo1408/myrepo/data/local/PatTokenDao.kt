package com.github.samo1408.myrepo.data.local

import androidx.room.*

@Dao
interface PatTokenDao {
    @Query("SELECT * FROM pat_tokens WHERE id = 1 LIMIT 1")
    suspend fun getToken(): PatTokenEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveToken(token: PatTokenEntity)

    @Query("DELETE FROM pat_tokens")
    suspend fun deleteToken()
}
