package com.github.samo1408.myrepo.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.github.samo1408.myrepo.R
import com.github.samo1408.myrepo.data.remote.models.GitHubContent

class ContentAdapter(
    private val onFileClick: (GitHubContent) -> Unit,
    private val onFolderClick: (GitHubContent) -> Unit
) : ListAdapter<GitHubContent, ContentAdapter.ViewHolder>(DiffCallback) {

    companion object DiffCallback : DiffUtil.ItemCallback<GitHubContent>() {
        override fun areItemsTheSame(old: GitHubContent, new: GitHubContent) = old.sha == new.sha
        override fun areContentsTheSame(old: GitHubContent, new: GitHubContent) = old == new
    }

    val selectedItems = mutableSetOf<String>()
    var onSelectionChanged: (() -> Unit)? = null

    fun toggleSelection(sha: String) {
        if (selectedItems.remove(sha)) { /* was selected, now removed */ }
        else { selectedItems.add(sha) }
        onSelectionChanged?.invoke()
    }

    fun selectAll() {
        selectedItems.clear()
        selectedItems.addAll(currentList.map { it.sha })
        notifyDataSetChanged()
        onSelectionChanged?.invoke()
    }

    fun clearSelection() {
        selectedItems.clear()
        notifyDataSetChanged()
        onSelectionChanged?.invoke()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_content, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cbSelect: CheckBox = itemView.findViewById(R.id.cbSelect)
        private val tvName: TextView = itemView.findViewById(R.id.tvContentName)
        private val tvSize: TextView = itemView.findViewById(R.id.tvContentSize)

        fun bind(content: GitHubContent) {
            val isDir = content.type == "dir"
            tvName.text = if (isDir) "📁 ${content.name}" else "📄 ${content.name}"
            tvSize.text = if (!isDir) formatSize(content.size) else ""

            cbSelect.visibility = View.VISIBLE
            cbSelect.isChecked = selectedItems.contains(content.sha)
            cbSelect.setOnClickListener {
                toggleSelection(content.sha)
            }

            itemView.setOnClickListener {
                if (isDir) onFolderClick(content) else onFileClick(content)
            }
        }

        private fun formatSize(bytes: Int): String = when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> "${"%.1f".format(bytes / (1024.0 * 1024.0))} MB"
        }
    }
}
