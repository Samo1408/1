package com.github.samo1408.myrepo.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pat_tokens")
data class PatTokenEntity(
    @PrimaryKey val id: Int = 1,
    val token: String,
    val savedAt: Long = System.currentTimeMillis()
)
