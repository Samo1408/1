package com.github.samo1408.myrepo.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.samo1408.myrepo.R
import com.github.samo1408.myrepo.data.remote.models.GitHubBranch

class BranchAdapter(
    private val onDeleteClick: (GitHubBranch) -> Unit,
    private val onRenameClick: (GitHubBranch) -> Unit,
    private val onSetDefaultClick: (GitHubBranch) -> Unit = {},
    private val onBranchClick: (GitHubBranch) -> Unit = {}
) : RecyclerView.Adapter<BranchAdapter.ViewHolder>() {

    private var branches = listOf<GitHubBranch>()
    var defaultBranch: String = "main"

    fun submitList(list: List<GitHubBranch>) {
        branches = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_branch, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(branches[position])
    }

    override fun getItemCount(): Int = branches.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvBranchName: android.widget.TextView = itemView.findViewById(R.id.tvBranchName)
        private val btnRename: android.widget.ImageButton = itemView.findViewById(R.id.btnRenameBranch)
        private val btnDelete: android.widget.ImageButton = itemView.findViewById(R.id.btnDeleteBranch)
        private val btnSetDefault: android.widget.ImageButton = itemView.findViewById(R.id.btnSetDefault)

        fun bind(branch: GitHubBranch) {
            val isDefault = branch.name == defaultBranch
            tvBranchName.text = if (isDefault) "⭐ ${branch.name} (default)" else branch.name
            btnRename.setOnClickListener { onRenameClick(branch) }
            btnDelete.setOnClickListener { onDeleteClick(branch) }
            btnSetDefault.visibility = if (isDefault) View.GONE else View.VISIBLE
            btnSetDefault.setOnClickListener { onSetDefaultClick(branch) }
            itemView.setOnClickListener { onBranchClick(branch) }
        }
    }
}
