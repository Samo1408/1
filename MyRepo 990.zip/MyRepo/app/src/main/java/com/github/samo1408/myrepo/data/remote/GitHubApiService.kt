package com.github.samo1408.myrepo.data.remote

import com.github.samo1408.myrepo.data.remote.models.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface GitHubApiService {

    // ── User ──
    @GET("user")
    suspend fun getAuthenticatedUser(): Response<GitHubUser>

    // ── Repositories ──
    @GET("user/repos")
    suspend fun getUserRepos(
        @Query("per_page") perPage: Int = 100,
        @Query("page") page: Int = 1,
        @Query("sort") sort: String = "updated"
    ): Response<List<GitHubRepo>>

    @POST("user/repos")
    suspend fun createRepo(@Body request: CreateRepoRequest): Response<GitHubRepo>

    @GET("repos/{owner}/{repo}")
    suspend fun getRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String
    ): Response<GitHubRepo>

    @PATCH("repos/{owner}/{repo}")
    suspend fun renameRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body request: RenameRepoRequest
    ): Response<GitHubRepo>

    @DELETE("repos/{owner}/{repo}")
    suspend fun deleteRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String
    ): Response<ResponseBody>

    // ── Branches ──
    @GET("repos/{owner}/{repo}/branches")
    suspend fun listBranches(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 100
    ): Response<List<GitHubBranch>>

    @GET("repos/{owner}/{repo}/git/refs/heads/{branch}")
    suspend fun getBranchRef(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("branch") branch: String
    ): Response<GitHubRef>

    @POST("repos/{owner}/{repo}/git/refs")
    suspend fun createBranch(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body request: CreateBranchRequest
    ): Response<GitHubRef>

    @DELETE("repos/{owner}/{repo}/git/refs/heads/{branch}")
    suspend fun deleteBranch(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("branch") branch: String
    ): Response<ResponseBody>

    @PATCH("repos/{owner}/{repo}")
    suspend fun updateRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: Map<String, @JvmSuppressWildcards Any>
    ): Response<GitHubRepo>

    @PATCH("repos/{owner}/{repo}/git/refs/heads/{oldBranch}")
    suspend fun renameBranch(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("oldBranch") oldBranch: String,
        @Body request: CreateBranchRequest
    ): Response<GitHubRef>

    // ── Contents ──
    @GET("repos/{owner}/{repo}/contents")
    suspend fun getRootContents(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("ref") ref: String? = null
    ): Response<ResponseBody>

    @GET("repos/{owner}/{repo}/contents/{path}")
    suspend fun getContents(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path", encoded = true) path: String,
        @Query("ref") ref: String? = null
    ): Response<ResponseBody>

    @PUT("repos/{owner}/{repo}/contents/{path}")
    suspend fun createOrUpdateFile(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path") path: String,
        @Body request: CreateFileRequest
    ): Response<Any>

    // deleteFileContent handled via OkHttp directly (Retrofit @DELETE + @Body not supported)

    // ── Archive download ──
    @GET("repos/{owner}/{repo}/zipball/{ref}")
    @Streaming
    suspend fun downloadRepoZip(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("ref") ref: String = "main"
    ): Response<ResponseBody>

    // ── Import from git ──
    @PUT("repos/{owner}/{repo}/import")
    suspend fun importRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: Map<String, String>
    ): Response<Any>
}
