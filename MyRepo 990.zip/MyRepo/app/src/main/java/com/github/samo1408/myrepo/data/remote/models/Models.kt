package com.github.samo1408.myrepo.data.remote.models

import com.google.gson.annotations.SerializedName

data class GitHubRepo(
    val id: Long,
    val name: String,
    @SerializedName("full_name") val fullName: String,
    val description: String?,
    @SerializedName("private") val isPrivate: Boolean,
    @SerializedName("html_url") val htmlUrl: String,
    @SerializedName("clone_url") val cloneUrl: String,
    @SerializedName("default_branch") val defaultBranch: String? = null,
    @SerializedName("stargazers_count") val stars: Int,
    @SerializedName("forks_count") val forks: Int,
    val language: String?,
    @SerializedName("updated_at") val updatedAt: String,
    @SerializedName("owner") val owner: GitHubOwner
)

data class GitHubOwner(
    val login: String,
    @SerializedName("avatar_url") val avatarUrl: String
)

data class GitHubBranch(
    val name: String,
    val commit: BranchCommit,
    val protected: Boolean
)

data class BranchCommit(
    val sha: String,
    val url: String
)

data class GitHubContent(
    val name: String,
    val path: String,
    val sha: String,
    val size: Int,
    val url: String,
    @SerializedName("html_url") val htmlUrl: String,
    @SerializedName("git_url") val gitUrl: String,
    @SerializedName("download_url") val downloadUrl: String?,
    val type: String, // "file" or "dir"
    val content: String?,
    val encoding: String?
)

data class CreateRepoRequest(
    val name: String,
    val description: String? = null,
    @SerializedName("private") val isPrivate: Boolean = false,
    @SerializedName("auto_init") val autoInit: Boolean = true
)

data class RenameRepoRequest(
    val name: String
)

data class CreateBranchRequest(
    val ref: String,
    val sha: String
)

data class GitHubRef(
    @SerializedName("ref") val refName: String,
    val node_id: String,
    val url: String,
    val `object`: GitHubObject
)

data class GitHubObject(
    val sha: String,
    val type: String
)

data class CreateFileRequest(
    val message: String,
    val content: String, // base64
    val sha: String? = null,
    val branch: String? = null
)

data class GitHubUser(
    val login: String,
    @SerializedName("avatar_url") val avatarUrl: String,
    val name: String?,
    val email: String?,
    @SerializedName("public_repos") val publicRepos: Int,
    @SerializedName("private_repos") val totalPrivateRepos: Int?,
    val following: Int,
    val followers: Int
)
