package com.github.samo1408.myrepo.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.samo1408.myrepo.data.remote.models.GitHubRepo
import com.github.samo1408.myrepo.databinding.ItemRepoBinding

class RepoAdapter(
    private val onRepoClick: (GitHubRepo) -> Unit
) : RecyclerView.Adapter<RepoAdapter.ViewHolder>() {

    private var repos = listOf<GitHubRepo>()

    fun submitList(list: List<GitHubRepo>) {
        repos = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRepoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(repos[position])
    }

    override fun getItemCount(): Int = repos.size

    inner class ViewHolder(private val binding: ItemRepoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(repo: GitHubRepo) {
            binding.tvRepoName.text = repo.name
            binding.tvRepoDesc.text = repo.description ?: "No description"
            binding.tvRepoLang.text = repo.language ?: ""
            binding.tvRepoStars.text = "★ ${repo.stars}"
            binding.tvRepoVisibility.text = if (repo.isPrivate) "🔒 Private" else "🌐 Public"
            binding.root.setOnClickListener { onRepoClick(repo) }
        }
    }
}
