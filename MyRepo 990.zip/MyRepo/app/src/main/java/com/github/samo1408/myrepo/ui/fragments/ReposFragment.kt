package com.github.samo1408.myrepo.ui.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.data.remote.models.GitHubRepo
import com.github.samo1408.myrepo.databinding.FragmentReposBinding
import com.github.samo1408.myrepo.ui.adapters.RepoAdapter
import com.github.samo1408.myrepo.ui.main.MainActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class ReposFragment : Fragment() {

    private var _binding: FragmentReposBinding? = null
    private val binding get() = _binding!!
    private val repo get() = (requireActivity().application as MyRepoApp).gitHubRepository
    private lateinit var adapter: RepoAdapter
    private var reposList = listOf<GitHubRepo>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReposBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = RepoAdapter { clickedRepo ->
            (requireActivity() as MainActivity).openRepoDetail(clickedRepo)
        }

        binding.recyclerRepos.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerRepos.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadRepos() }

        binding.fabActions.setOnClickListener { showRepoActionsMenu() }

        loadRepos()
    }

    private fun loadRepos() {
        binding.progressBar.visibility = View.VISIBLE
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val result = repo.getUserRepos()
            result.fold(
                onSuccess = { repos ->
                    reposList = repos
                    adapter.submitList(repos)
                    binding.tvEmpty.visibility = if (repos.isEmpty()) View.VISIBLE else View.GONE
                },
                onFailure = { e ->
                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            )
            binding.progressBar.visibility = View.GONE
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun showRepoActionsMenu() {
        val items = arrayOf("New Repository", "Import from Git", "Delete Repository", "Rename Repository")
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Repository Actions")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showCreateRepoDialog()
                    1 -> showImportRepoDialog()
                    2 -> showDeleteRepoDialog()
                    3 -> showRenameRepoDialog()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCreateRepoDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(
            com.github.samo1408.myrepo.R.layout.dialog_create_repo, null
        )
        val etName = view.findViewById<TextInputEditText>(com.github.samo1408.myrepo.R.id.etRepoName)
        val etDesc = view.findViewById<TextInputEditText>(com.github.samo1408.myrepo.R.id.etRepoDesc)
        val cbPrivate = view.findViewById<com.google.android.material.checkbox.MaterialCheckBox>(
            com.github.samo1408.myrepo.R.id.cbPrivate
        )

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("New Repository")
            .setView(view)
            .setPositiveButton("Create") { _, _ ->
                val name = etName.text.toString().trim()
                val desc = etDesc.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(requireContext(), "Name is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    val result = repo.createRepo(name, desc, cbPrivate.isChecked)
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(), "Repo created: $name", Toast.LENGTH_SHORT).show()
                            loadRepos()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showImportRepoDialog() {
        val etUrl = EditText(requireContext()).apply { hint = "Git clone URL (https://...)" }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Import from Git")
            .setView(etUrl)
            .setPositiveButton("Import") { _, _ ->
                val url = etUrl.text.toString().trim()
                if (url.isBlank()) {
                    Toast.makeText(requireContext(), "URL is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val repoName = url.substringAfterLast("/").replace(".git", "")
                lifecycleScope.launch {
                    // First create the repo
                    val createResult = repo.createRepo(repoName, "Imported from $url", false)
                    createResult.fold(
                        onSuccess = { created ->
                            // Then trigger import
                            val importResult = repo.importRepo(
                                created.owner.login, repoName, url
                            )
                            importResult.fold(
                                onSuccess = {
                                    Toast.makeText(requireContext(),
                                        "Import started for $repoName", Toast.LENGTH_SHORT).show()
                                    loadRepos()
                                },
                                onFailure = { e ->
                                    Toast.makeText(requireContext(),
                                        "Import error: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            )
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteRepoDialog() {
        if (reposList.isEmpty()) {
            Toast.makeText(requireContext(), "No repositories to delete", Toast.LENGTH_SHORT).show()
            return
        }
        val names = reposList.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select repo to delete")
            .setItems(names) { _, which ->
                val selected = reposList[which]
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Confirm Delete")
                    .setMessage("Are you sure you want to delete '${selected.name}'?\nThis cannot be undone!")
                    .setPositiveButton("Delete") { _, _ ->
                        lifecycleScope.launch {
                            val result = repo.deleteRepo(selected.owner.login, selected.name)
                            result.fold(
                                onSuccess = {
                                    Toast.makeText(requireContext(),
                                        "Deleted: ${selected.name}", Toast.LENGTH_SHORT).show()
                                    loadRepos()
                                },
                                onFailure = { e ->
                                    Toast.makeText(requireContext(),
                                        "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRenameRepoDialog() {
        if (reposList.isEmpty()) {
            Toast.makeText(requireContext(), "No repositories to rename", Toast.LENGTH_SHORT).show()
            return
        }
        val names = reposList.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select repo to rename")
            .setItems(names) { _, which ->
                val selected = reposList[which]
                val etNewName = EditText(requireContext()).apply {
                    setText(selected.name)
                    hint = "New repository name"
                }
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Rename '${selected.name}'")
                    .setView(etNewName)
                    .setPositiveButton("Rename") { _, _ ->
                        val newName = etNewName.text.toString().trim()
                        if (newName.isBlank()) {
                            Toast.makeText(requireContext(), "Name required", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        lifecycleScope.launch {
                            val result = repo.renameRepo(selected.owner.login, selected.name, newName)
                            result.fold(
                                onSuccess = {
                                    Toast.makeText(requireContext(),
                                        "Renamed to $newName", Toast.LENGTH_SHORT).show()
                                    loadRepos()
                                },
                                onFailure = { e ->
                                    Toast.makeText(requireContext(),
                                        "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
