package com.github.samo1408.myrepo.data.repository

import com.github.samo1408.myrepo.data.local.AppDatabase
import com.github.samo1408.myrepo.data.local.PatTokenEntity
import com.github.samo1408.myrepo.data.remote.GitHubClient
import com.github.samo1408.myrepo.data.remote.models.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody

class GitHubRepository(private val database: AppDatabase) {

    suspend fun savePatToken(token: String) {
        database.patTokenDao().saveToken(PatTokenEntity(token = token))
        GitHubClient.setToken(token)
    }

    suspend fun loadSavedToken(): String? {
        return database.patTokenDao().getToken()?.token
    }

    suspend fun deleteSavedToken() {
        database.patTokenDao().deleteToken()
    }

    suspend fun testAuth(): Result<GitHubUser> = apiCall {
        val response = GitHubClient.getService().getAuthenticatedUser()
        if (response.isSuccessful) response.body()!!
        else throw Exception("Auth failed: ${response.code()}")
    }

    suspend fun getUserRepos(): Result<List<GitHubRepo>> = apiCall {
        val allRepos = mutableListOf<GitHubRepo>()
        var page = 1
        while (true) {
            val response = GitHubClient.getService().getUserRepos(page = page)
            if (response.isSuccessful) {
                val repos = response.body() ?: emptyList()
                allRepos.addAll(repos)
                if (repos.size < 100) break
                page++
            } else throw Exception("Failed to fetch repos: ${response.code()}")
        }
        allRepos
    }

    suspend fun createRepo(name: String, description: String, isPrivate: Boolean): Result<GitHubRepo> = apiCall {
        val response = GitHubClient.getService().createRepo(
            CreateRepoRequest(name = name, description = description, isPrivate = isPrivate)
        )
        if (response.isSuccessful) response.body()!!
        else throw Exception("Create repo failed: ${response.code()} ${response.message()}")
    }

    suspend fun renameRepo(owner: String, oldName: String, newName: String): Result<GitHubRepo> = apiCall {
        val response = GitHubClient.getService().renameRepo(owner, oldName, RenameRepoRequest(newName))
        if (response.isSuccessful) response.body()!!
        else throw Exception("Rename failed: ${response.code()}")
    }

    suspend fun deleteRepo(owner: String, repo: String): Result<Unit> = apiCall {
        val response = GitHubClient.getService().deleteRepo(owner, repo)
        if (response.isSuccessful) Unit
        else throw Exception("Delete failed: ${response.code()}")
    }

    suspend fun getRepo(owner: String, repo: String): Result<GitHubRepo> = apiCall {
        val response = GitHubClient.getService().getRepo(owner, repo)
        if (response.isSuccessful) response.body()!!
        else throw Exception("Get repo failed: ${response.code()}")
    }

    suspend fun importRepo(owner: String, repo: String, cloneUrl: String): Result<Unit> = apiCall {
        val body = mapOf(
            "vcs" to "git",
            "vcs_url" to cloneUrl
        )
        val response = GitHubClient.getService().importRepo(owner, repo, body)
        if (response.isSuccessful) Unit
        else throw Exception("Import failed: ${response.code()} ${response.message()}")
    }

    // Branches
    suspend fun listBranches(owner: String, repo: String): Result<List<GitHubBranch>> = apiCall {
        val response = GitHubClient.getService().listBranches(owner, repo)
        if (response.isSuccessful) response.body() ?: emptyList()
        else throw Exception("List branches failed: ${response.code()}")
    }

    suspend fun createBranch(owner: String, repo: String, branchName: String, sourceSha: String): Result<GitHubRef> = apiCall {
        val response = GitHubClient.getService().createBranch(
            owner, repo,
            CreateBranchRequest(ref = "refs/heads/$branchName", sha = sourceSha)
        )
        if (response.isSuccessful) response.body()!!
        else throw Exception("Create branch failed: ${response.code()}")
    }

    suspend fun deleteBranch(owner: String, repo: String, branch: String): Result<Unit> = apiCall {
        val response = GitHubClient.getService().deleteBranch(owner, repo, branch)
        if (response.isSuccessful) Unit
        else throw Exception("Delete branch failed: ${response.code()}")
    }

    suspend fun renameBranch(owner: String, repo: String, oldName: String, newName: String): Result<GitHubRef> = apiCall {
        val refResponse = GitHubClient.getService().getBranchRef(owner, repo, oldName)
        if (!refResponse.isSuccessful) throw Exception("Get branch ref failed")
        val sha = refResponse.body()!!.`object`.sha

        val createResp = GitHubClient.getService().createBranch(
            owner, repo,
            CreateBranchRequest(ref = "refs/heads/$newName", sha = sha)
        )
        if (!createResp.isSuccessful) throw Exception("Create new branch failed")

        val deleteResp = GitHubClient.getService().deleteBranch(owner, repo, oldName)
        if (!deleteResp.isSuccessful) throw Exception("Delete old branch failed")

        createResp.body()!!
    }

    suspend fun setDefaultBranch(owner: String, repo: String, branchName: String): Result<GitHubRepo> = apiCall {
        val response = GitHubClient.getService().updateRepo(owner, repo, mapOf("default_branch" to branchName))
        if (response.isSuccessful) response.body()!!
        else throw Exception("Set default branch failed: ${response.code()} ${response.message()}")
    }

    // Contents
    private val gson = Gson()

    suspend fun getContents(owner: String, repo: String, path: String, ref: String? = null): Result<List<GitHubContent>> = apiCall {
        val resp = if (path.isEmpty()) {
            GitHubClient.getService().getRootContents(owner, repo, ref)
        } else {
            GitHubClient.getService().getContents(owner, repo, path, ref)
        }
        if (!resp.isSuccessful) throw Exception("Get contents failed: ${resp.code()} ${resp.message()}")
        val body = resp.body()?.string() ?: throw Exception("Empty response body")
        return@apiCall parseContentsJson(body)
    }

    suspend fun getFileContent(owner: String, repo: String, path: String, ref: String? = null): Result<GitHubContent> = apiCall {
        val resp = GitHubClient.getService().getContents(owner, repo, path, ref)
        if (!resp.isSuccessful) throw Exception("Get file failed: ${resp.code()}")
        val body = resp.body()?.string() ?: throw Exception("Empty")
        gson.fromJson(body, GitHubContent::class.java)
    }

    suspend fun copyFileToRepo(
        owner: String, repo: String, path: String,
        targetRepoFull: String, targetPath: String,
        branch: String? = null
    ): Result<Unit> = apiCall {
        val parts = targetRepoFull.split("/")
        if (parts.size != 2) throw Exception("Target must be owner/repo format")
        val tOwner = parts[0]; val tRepo = parts[1]
        val content = getFileContent(owner, repo, path, branch).getOrThrow()
        if (content.type == "dir") throw Exception("Cannot copy folders, only files")
        val raw = content.content?.replace("\n", "") ?: throw Exception("Cannot read file content (may be binary)")
        val resp = GitHubClient.getService().createOrUpdateFile(
            tOwner, tRepo, targetPath,
            CreateFileRequest(message = "Copy $path from $owner/$repo", content = raw, branch = branch)
        )
        if (resp.isSuccessful) Unit
        else throw Exception("Copy failed: ${resp.code()} ${resp.message()}")
    }

    private fun parseContentsJson(json: String): List<GitHubContent> {
        return try {
            val listType = object : TypeToken<List<GitHubContent>>() {}.type
            gson.fromJson(json, listType)
        } catch (e: Exception) {
            // Single file returned as object, not array
            listOf(gson.fromJson(json, GitHubContent::class.java))
        }
    }

    suspend fun createFile(
        owner: String, repo: String, path: String,
        message: String, contentBase64: String, branch: String? = null
    ): Result<Unit> = apiCall {
        val response = GitHubClient.getService().createOrUpdateFile(
            owner, repo, path,
            CreateFileRequest(message = message, content = contentBase64, branch = branch)
        )
        if (response.isSuccessful) Unit
        else throw Exception("Create file failed: ${response.code()} ${response.message()}")
    }

    suspend fun updateFile(
        owner: String, repo: String, path: String,
        message: String, contentBase64: String, sha: String, branch: String? = null
    ): Result<Unit> = apiCall {
        val response = GitHubClient.getService().createOrUpdateFile(
            owner, repo, path,
            CreateFileRequest(message = message, content = contentBase64, sha = sha, branch = branch)
        )
        if (response.isSuccessful) Unit
        else throw Exception("Update file failed: ${response.code()}")
    }

    suspend fun deleteFileContent(
        owner: String, repo: String, path: String, sha: String, branch: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val bodyMap = mutableMapOf("message" to "Delete $path", "sha" to sha)
            branch?.let { bodyMap["branch"] = it }
            val json = gson.toJson(bodyMap)
            val requestBody = okhttp3.RequestBody.create(
                "application/json; charset=utf-8".toMediaType(), json
            )
            val request = okhttp3.Request.Builder()
                .url("https://api.github.com/repos/$owner/$repo/contents/$path")
                .method("DELETE", requestBody)
                .build()
            val response = GitHubClient.getClient().newCall(request).execute()
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Delete failed: ${response.code} ${response.message}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadRepoZip(owner: String, repo: String, ref: String): Result<ResponseBody> = apiCall {
        val response = GitHubClient.getService().downloadRepoZip(owner, repo, ref)
        if (response.isSuccessful) response.body()!!
        else throw Exception("Download failed: ${response.code()}")
    }

    private suspend fun <T> apiCall(block: suspend () -> T): Result<T> {
        return withContext(Dispatchers.IO) {
            try {
                Result.success(block())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
