package com.github.samo1408.myrepo.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PatTokenEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun patTokenDao(): PatTokenDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val dbFile = context.getExternalFilesDir(null)?.resolve("MyRepo") ?: context.filesDir
                dbFile.mkdirs()
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    dbFile.resolve("pattoken.db").absolutePath
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
