package com.github.samo1408.myrepo.ui.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.data.remote.GitHubClient
import com.github.samo1408.myrepo.databinding.FragmentCommandsBinding
import kotlinx.coroutines.launch

class CommandsFragment : Fragment() {

    private var _binding: FragmentCommandsBinding? = null
    private val binding get() = _binding!!
    private val repo get() = (requireActivity().application as MyRepoApp).gitHubRepository

    // CLI state
    private var cliRepo: String = ""
    private var cliPath: String = ""
    private var cliBranch: String = "main"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCommandsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvCliOutput.movementMethod = ScrollingMovementMethod()
        binding.etCliInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEND) {
                val cmd = binding.etCliInput.text.toString().trim()
                if (cmd.isNotEmpty()) {
                    appendCli("$ ${cmd}")
                    executeCli(cmd)
                    binding.etCliInput.text = null
                }
                true
            } else false
        }

        binding.btnCopyToken.setOnClickListener { copyToken() }
        binding.btnShowToken.setOnClickListener {
            binding.tvTokenDisplay.text = GitHubClient.getToken() ?: "No token"
            binding.tvTokenDisplay.visibility = View.VISIBLE
        }
        binding.btnOpenGithub.setOnClickListener { openGithubWeb() }
        binding.btnShowProfile.setOnClickListener { showProfile() }
        binding.btnListReposCmd.setOnClickListener { listReposCmd() }
        binding.btnOpenRepo.setOnClickListener { openRepoPrompt() }

        // Focus CLI input when card is tapped
        binding.cliCard.setOnClickListener { binding.etCliInput.requestFocus() }
    }

    // ── CLI Engine ──

    private fun executeCli(cmd: String) {
        val parts = cmd.trim().split("\\s+".toRegex())
        val op = parts[0].lowercase()
        val args = parts.drop(1)
        lifecycleScope.launch {
            try {
                when (op) {
                    "help" -> showCliHelp()
                    "repo" -> {
                        if (args.isEmpty()) appendCli("usage: repo owner/repo")
                        else { cliRepo = args[0]; cliPath = ""; appendCli("repo set → $cliRepo") }
                    }
                    "ls" -> {
                        if (cliRepo.isEmpty()) { appendCli("set repo first: repo owner/repo"); return@launch }
                        val path = args.firstOrNull() ?: cliPath
                        val partsRepo = cliRepo.split("/")
                        val r = repo.getContents(partsRepo[0], partsRepo[1], path, cliBranch)
                        r.fold(
                            onSuccess = { items ->
                                if (items.isEmpty()) appendCli("(empty)")
                                else items.forEach { i ->
                                    val icon = if (i.type == "dir") "📁" else "📄"
                                    val sz = if (i.type != "dir") "  ${formatSize(i.size)}" else ""
                                    appendCli("  $icon ${i.name}$sz")
                                }
                            },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "cd" -> {
                        if (args.isEmpty()) { cliPath = ""; appendCli("cd /") }
                        else if (args[0] == "..") {
                            cliPath = if (cliPath.contains("/")) cliPath.substringBeforeLast("/") else ""
                            appendCli("cd ${if (cliPath.isEmpty()) "/" else cliPath}")
                        } else {
                            cliPath = if (cliPath.isEmpty()) args[0] else "$cliPath/${args[0]}"
                            appendCli("cd $cliPath")
                        }
                    }
                    "pwd" -> appendCli(if (cliPath.isEmpty()) "/" else cliPath)
                    "cat" -> {
                        if (cliRepo.isEmpty() || args.isEmpty()) { appendCli("usage: cat <file>"); return@launch }
                        val fp = if (cliPath.isEmpty()) args[0] else "$cliPath/${args[0]}"
                        val partsRepo = cliRepo.split("/")
                        val r = repo.getFileContent(partsRepo[0], partsRepo[1], fp, cliBranch)
                        r.fold(
                            onSuccess = { f ->
                                val txt = if (f.content != null && f.encoding == "base64")
                                    Base64.decode(f.content!!.replace("\n", ""), Base64.DEFAULT).decodeToString()
                                else "(binary or empty)"
                                appendCli(txt.take(2000))
                            },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "rm" -> {
                        if (cliRepo.isEmpty() || args.isEmpty()) { appendCli("usage: rm <file>"); return@launch }
                        val fp = if (cliPath.isEmpty()) args[0] else "$cliPath/${args[0]}"
                        val partsRepo = cliRepo.split("/")
                        // Get sha first
                        val c = repo.getFileContent(partsRepo[0], partsRepo[1], fp, cliBranch)
                        c.fold(
                            onSuccess = { f ->
                                val dr = repo.deleteFileContent(partsRepo[0], partsRepo[1], fp, f.sha, cliBranch)
                                dr.fold(
                                    onSuccess = { appendCli("deleted: $fp") },
                                    onFailure = { appendCli("error: ${it.message}") }
                                )
                            },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "mkdir" -> {
                        if (cliRepo.isEmpty() || args.isEmpty()) { appendCli("usage: mkdir <name>"); return@launch }
                        val fp = if (cliPath.isEmpty()) "${args[0]}/.gitkeep" else "$cliPath/${args[0]}/.gitkeep"
                        val partsRepo = cliRepo.split("/")
                        val b64 = Base64.encodeToString("".toByteArray(), Base64.NO_WRAP)
                        val r = repo.createFile(partsRepo[0], partsRepo[1], fp, "create ${args[0]}", b64, cliBranch)
                        r.fold(
                            onSuccess = { appendCli("created dir: ${args[0]}") },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "touch" -> {
                        if (cliRepo.isEmpty() || args.isEmpty()) { appendCli("usage: touch <file> [content]"); return@launch }
                        val fp = if (cliPath.isEmpty()) args[0] else "$cliPath/${args[0]}"
                        val content = if (args.size > 1) args.drop(1).joinToString(" ") else ""
                        val partsRepo = cliRepo.split("/")
                        val b64 = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)
                        val r = repo.createFile(partsRepo[0], partsRepo[1], fp, "create ${args[0]}", b64, cliBranch)
                        r.fold(
                            onSuccess = { appendCli("created: ${args[0]}") },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "branch" -> {
                        if (cliRepo.isEmpty() || args.isEmpty()) { appendCli("usage: branch <name>"); return@launch }
                        cliBranch = args[0]
                        appendCli("branch → $cliBranch")
                    }
                    "branches" -> {
                        if (cliRepo.isEmpty()) { appendCli("set repo first: repo owner/repo"); return@launch }
                        val partsRepo = cliRepo.split("/")
                        val r = repo.listBranches(partsRepo[0], partsRepo[1])
                        r.fold(
                            onSuccess = { list ->
                                list.forEach { b ->
                                    val star = if (b.name == cliBranch) "⭐" else "  "
                                    appendCli("  $star ${b.name}")
                                }
                            },
                            onFailure = { appendCli("error: ${it.message}") }
                        )
                    }
                    "clear" -> {
                        binding.tvCliOutput.text = ""
                    }
                    else -> appendCli("unknown: $op — type 'help'")
                }
            } catch (e: Exception) {
                appendCli("error: ${e.message}")
            }
        }
    }

    private fun appendCli(text: String) {
        binding.tvCliOutput.append(text + "\n")
        // Scroll to bottom
        binding.tvCliOutput.post {
            val scroll = binding.cliCard.findViewById<android.widget.ScrollView>(
                binding.cliCard.findViewById<android.view.ViewGroup>(android.R.id.content)
                    ?.getChildAt(0)?.id ?: return@post
            )
        }
        // Simpler: scroll the parent ScrollView
        val parent = binding.tvCliOutput.parent as? android.widget.ScrollView
        parent?.post { parent.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showCliHelp() {
        appendCli("""
══════════════════════════════
  GitHub CLI — Commands
══════════════════════════════
  repo <owner/name>   select repo
  ls [path]            list files
  cd <dir> | cd ..    change directory
  pwd                  show current path
  cat <file>           show file content
  rm <file>            delete file
  mkdir <name>         create folder
  touch <file> [text]  create file
  branch <name>        switch branch
  branches             list branches
  clear                clear screen
  help                 this help
══════════════════════════════
        """.trimIndent())
    }

    private fun formatSize(bytes: Int): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${"%.1f".format(bytes / (1024.0 * 1024.0))} MB"
    }

    // ── Existing helpers ──

    private fun copyToken() {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("PAT Token", GitHubClient.getToken() ?: ""))
        Toast.makeText(requireContext(), "Token copied", Toast.LENGTH_SHORT).show()
    }

    private fun openGithubWeb() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com")))
    }

    private fun showProfile() {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = repo.testAuth()
            result.fold(
                onSuccess = { user ->
                    binding.tvCommandOutput.text = """
👤 Profile
━━━━━━━━━━
Login: ${user.login}
Name: ${user.name ?: "N/A"}
Email: ${user.email ?: "N/A"}
Public Repos: ${user.publicRepos}
Followers: ${user.followers}  Following: ${user.following}
                    """.trimIndent()
                    binding.tvCommandOutput.visibility = View.VISIBLE
                },
                onFailure = { e ->
                    binding.tvCommandOutput.text = "Error: ${e.message}"
                    binding.tvCommandOutput.visibility = View.VISIBLE
                }
            )
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun listReposCmd() {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = repo.getUserRepos()
            result.fold(
                onSuccess = { repos ->
                    val sb = StringBuilder("📚 Repos (${repos.size})\n━━━━━━━━━━\n")
                    repos.forEach { r ->
                        val vis = if (r.isPrivate) "🔒" else "🌐"
                        sb.append("$vis ${r.fullName}\n")
                    }
                    binding.tvCommandOutput.text = sb.toString()
                    binding.tvCommandOutput.visibility = View.VISIBLE
                },
                onFailure = { e ->
                    binding.tvCommandOutput.text = "Error: ${e.message}"
                    binding.tvCommandOutput.visibility = View.VISIBLE
                }
            )
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun openRepoPrompt() {
        val et = EditText(requireContext()).apply { hint = "owner/repo (e.g. Samo1408/Wifi-Tools)" }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Open Repository")
            .setView(et)
            .setPositiveButton("Open") { _, _ ->
                val input = et.text.toString().trim()
                if (input.isNotBlank()) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/$input")))
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
