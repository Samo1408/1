package com.github.samo1408.myrepo.ui.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.data.local.AppDatabase
import com.github.samo1408.myrepo.data.remote.GitHubClient
import com.github.samo1408.myrepo.databinding.FragmentSettingsBinding
import com.github.samo1408.myrepo.ui.login.LoginActivity
import com.github.samo1408.myrepo.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val repo get() = (requireActivity().application as MyRepoApp).gitHubRepository

    private val exportCookiesLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        uri?.let { exportCookiesTo(it) }
    }

    private val importCookiesLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { importCookiesFrom(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Save PAT Token
        binding.btnSaveToken.setOnClickListener {
            val token = GitHubClient.getToken()
            if (token != null) {
                lifecycleScope.launch {
                    repo.savePatToken(token)
                    Toast.makeText(requireContext(),
                        "Token saved to pattoken.db", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(),
                    "No token to save", Toast.LENGTH_SHORT).show()
            }
        }

        // WebView Login
        binding.btnWebViewLogin.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://github.com/login"))
            startActivity(intent)
            Toast.makeText(requireContext(),
                "After logging in, go to Settings → Developer settings → Personal access tokens to create a token",
                Toast.LENGTH_LONG).show()
        }

        // Create PAT Token directly
        binding.btnCreatePatToken.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://github.com/settings/tokens/new"))
            startActivity(intent)
        }

        // Export Cookies
        binding.btnExportCookies.setOnClickListener {
            exportCookiesLauncher.launch("github_cookies.dat")
        }

        // Import Cookies
        binding.btnImportCookies.setOnClickListener {
            importCookiesLauncher.launch("*/*")
        }

        // Logout
        binding.btnLogout.setOnClickListener {
            lifecycleScope.launch {
                repo.deleteSavedToken()
                startActivity(Intent(requireContext(), LoginActivity::class.java))
                requireActivity().finish()
            }
        }

        // Clear Downloads
        binding.btnClearDownloads.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    FileUtils.deleteRecursive(FileUtils.getDownloadsDir(requireContext()))
                    FileUtils.getDownloadsDir(requireContext()).mkdirs()
                }
                Toast.makeText(requireContext(),
                    "Downloads cleared", Toast.LENGTH_SHORT).show()
            }
        }

        // Show token info
        binding.tvTokenStatus.text = if (GitHubClient.hasToken()) {
            "✅ Token Active: ${GitHubClient.getToken()?.take(6)}..."
        } else {
            "❌ No Token Set"
        }
    }

    private fun exportCookiesTo(uri: Uri) {
        lifecycleScope.launch {
            try {
                val webViewDir = FileUtils.getWebViewDataDir(requireContext())
                val cookieFile = File(webViewDir, "cookies")
                if (cookieFile.exists()) {
                    val bytes = FileUtils.readFileBytes(cookieFile)
                    requireContext().contentResolver.openOutputStream(uri)?.use {
                        it.write(bytes)
                    }
                    Toast.makeText(requireContext(),
                        "Cookies exported!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(),
                        "No cookies to export", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(),
                    "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun importCookiesFrom(uri: Uri) {
        lifecycleScope.launch {
            try {
                val bytes = requireContext().contentResolver.openInputStream(uri)?.readBytes()
                if (bytes != null) {
                    val webViewDir = FileUtils.getWebViewDataDir(requireContext())
                    val cookieFile = File(webViewDir, "cookies")
                    withContext(Dispatchers.IO) {
                        FileUtils.writeFile(cookieFile, bytes)
                    }
                    Toast.makeText(requireContext(),
                        "Cookies imported! Restart the app to apply.",
                        Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(),
                    "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
