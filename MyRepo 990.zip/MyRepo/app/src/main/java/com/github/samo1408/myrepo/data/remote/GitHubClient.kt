package com.github.samo1408.myrepo.data.remote

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object GitHubClient {
    private const val BASE_URL = "https://api.github.com/"

    private var patToken: String? = null
    private var apiService: GitHubApiService? = null
    private var okHttpClient: OkHttpClient? = null

    fun setToken(token: String) {
        patToken = token
        apiService = null // force rebuild
    }

    fun getToken(): String? = patToken

    fun getClient(): OkHttpClient {
        if (okHttpClient == null) {
            getService() // force build
        }
        return okHttpClient!!
    }

    fun getService(): GitHubApiService {
        if (apiService == null) {
            val token = patToken ?: throw IllegalStateException("PAT Token not set")

            val authInterceptor = Interceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("Accept", "application/vnd.github+json")
                    .addHeader("X-GitHub-Api-Version", "2022-11-28")
                    .build()
                chain.proceed(request)
            }

            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.HEADERS
            }

            val client = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(logging)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build()

            okHttpClient = client
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            apiService = retrofit.create(GitHubApiService::class.java)
        }
        return apiService!!
    }

    fun hasToken(): Boolean = !patToken.isNullOrBlank()
}
