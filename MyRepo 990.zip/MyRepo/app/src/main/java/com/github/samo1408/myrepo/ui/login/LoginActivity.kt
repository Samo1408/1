package com.github.samo1408.myrepo.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.databinding.ActivityLoginBinding
import com.github.samo1408.myrepo.ui.main.MainActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val repo get() = (application as MyRepoApp).gitHubRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check for saved token
        lifecycleScope.launch {
            val saved = repo.loadSavedToken()
            if (!saved.isNullOrBlank()) {
                binding.etToken.setText(saved)
            }
        }

        binding.btnLogin.setOnClickListener { performLogin() }

        binding.etToken.setOnEditorActionListener { _, _, _ ->
            performLogin()
            true
        }
    }

    private fun performLogin() {
        val token = binding.etToken.text.toString().trim()
        if (token.isBlank()) {
            Toast.makeText(this, "Please enter your PAT Token", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnLogin.isEnabled = false
        binding.etToken.isEnabled = false

        lifecycleScope.launch {
            try {
                repo.savePatToken(token)
                val result = repo.testAuth()
                if (result.isSuccess) {
                    val user = result.getOrNull()!!
                    Toast.makeText(this@LoginActivity,
                        "Welcome, ${user.login}!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this@LoginActivity,
                        "Login failed: ${result.exceptionOrNull()?.message}",
                        Toast.LENGTH_LONG).show()
                    repo.deleteSavedToken()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity,
                    "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.progressBar.visibility = View.GONE
                binding.btnLogin.isEnabled = true
                binding.etToken.isEnabled = true
            }
        }
    }
}
