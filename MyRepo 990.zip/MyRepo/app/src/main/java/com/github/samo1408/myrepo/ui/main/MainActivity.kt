package com.github.samo1408.myrepo.ui.main

import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.R
import com.github.samo1408.myrepo.data.remote.models.GitHubRepo
import com.github.samo1408.myrepo.databinding.ActivityMainBinding
import com.github.samo1408.myrepo.ui.fragments.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var drawerLayout: DrawerLayout
    private val repo get() = (application as MyRepoApp).gitHubRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = binding.toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        drawerLayout = binding.drawerLayout
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        binding.navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_repositories -> {
                    loadFragment(ReposFragment())
                    supportActionBar?.title = "Repositories"
                }
                R.id.nav_commands -> {
                    loadFragment(CommandsFragment())
                    supportActionBar?.title = "Commands"
                }
                R.id.nav_settings -> {
                    loadFragment(SettingsFragment())
                    supportActionBar?.title = "Settings"
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // Load repos by default
        if (savedInstanceState == null) {
            loadFragment(ReposFragment())
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    fun openRepoDetail(gitHubRepo: GitHubRepo) {
        val detailFragment = RepoDetailFragment.newInstance(
            owner = gitHubRepo.owner.login,
            repoName = gitHubRepo.name,
            defaultBranch = gitHubRepo.defaultBranch ?: "main",
            isPrivate = gitHubRepo.isPrivate,
            description = gitHubRepo.description ?: ""
        )
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, detailFragment)
            .addToBackStack(null)
            .commit()
        supportActionBar?.title = gitHubRepo.name
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            if (supportFragmentManager.backStackEntryCount > 0) {
                supportFragmentManager.popBackStack()
                supportActionBar?.title = "Repositories"
            } else {
                super.onBackPressed()
            }
        }
    }
}
