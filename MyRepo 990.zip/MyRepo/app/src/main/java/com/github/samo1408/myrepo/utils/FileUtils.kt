package com.github.samo1408.myrepo.utils

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileUtils {

    fun getMyRepoDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "MyRepo")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getDownloadsDir(context: Context): File {
        val dir = File(getMyRepoDir(context), "downloads")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getWebViewDataDir(context: Context): File {
        val dir = File(getMyRepoDir(context), "webview_data")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun writeFile(file: File, data: ByteArray) {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { it.write(data) }
    }

    fun readFileBytes(file: File): ByteArray {
        return FileInputStream(file).use { it.readBytes() }
    }

    fun createZip(sourceDir: File, outputZip: File) {
        ZipOutputStream(FileOutputStream(outputZip)).use { zos ->
            sourceDir.walkTopDown().filter { it.isFile }.forEach { file ->
                val entryName = file.relativeTo(sourceDir).path
                zos.putNextEntry(ZipEntry(entryName))
                FileInputStream(file).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    fun unzip(zipFile: File, targetDir: File) {
        targetDir.mkdirs()
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun deleteRecursive(file: File) {
        if (file.isDirectory) {
            file.listFiles()?.forEach { deleteRecursive(it) }
        }
        file.delete()
    }
}
