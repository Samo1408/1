package com.github.samo1408.myrepo

import android.app.Application
import com.github.samo1408.myrepo.data.local.AppDatabase
import com.github.samo1408.myrepo.data.repository.GitHubRepository
import com.github.samo1408.myrepo.utils.NotificationHelper

class MyRepoApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var gitHubRepository: GitHubRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        gitHubRepository = GitHubRepository(database)
        NotificationHelper.createChannel(this)
    }
}
