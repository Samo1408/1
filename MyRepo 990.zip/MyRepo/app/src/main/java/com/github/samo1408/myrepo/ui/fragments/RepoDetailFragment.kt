package com.github.samo1408.myrepo.ui.fragments

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.samo1408.myrepo.MyRepoApp
import com.github.samo1408.myrepo.data.remote.models.GitHubBranch
import com.github.samo1408.myrepo.data.remote.models.GitHubContent
import com.github.samo1408.myrepo.databinding.FragmentRepoDetailBinding
import com.github.samo1408.myrepo.ui.adapters.BranchAdapter
import com.github.samo1408.myrepo.ui.adapters.ContentAdapter
import com.github.samo1408.myrepo.utils.FileUtils
import com.github.samo1408.myrepo.utils.NotificationHelper
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import java.io.File

class RepoDetailFragment : Fragment() {

    companion object {
        private const val ARG_OWNER = "owner"
        private const val ARG_REPO = "repo"
        private const val ARG_BRANCH = "default_branch"
        private const val ARG_PRIVATE = "is_private"
        private const val ARG_DESC = "description"

        fun newInstance(owner: String, repoName: String, defaultBranch: String, isPrivate: Boolean, description: String): RepoDetailFragment {
            return RepoDetailFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_OWNER, owner)
                    putString(ARG_REPO, repoName)
                    putString(ARG_BRANCH, defaultBranch)
                    putBoolean(ARG_PRIVATE, isPrivate)
                    putString(ARG_DESC, description)
                }
            }
        }
    }

    private var _binding: FragmentRepoDetailBinding? = null
    private val binding get() = _binding!!
    private val repo get() = (requireActivity().application as MyRepoApp).gitHubRepository

    private lateinit var owner: String
    private lateinit var repoName: String
    private lateinit var currentBranch: String
    private var isPrivate: Boolean = false
    private var description: String = ""

    private lateinit var contentAdapter: ContentAdapter
    private lateinit var branchAdapter: BranchAdapter
    private var currentPath = ""
    private var branches = listOf<GitHubBranch>()
    private var contentItems = listOf<GitHubContent>()
    private var showHidden = false

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { handleFileUpload(it) }
    }

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let { handleFolderUpload(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRepoDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            owner = it.getString(ARG_OWNER)!!
            repoName = it.getString(ARG_REPO)!!
            currentBranch = it.getString(ARG_BRANCH)?.takeIf { b -> b.isNotBlank() } ?: "main"
            isPrivate = it.getBoolean(ARG_PRIVATE)
            description = it.getString(ARG_DESC)!!
        }

        binding.tvRepoInfo.text = "$owner/$repoName  |  ${if (isPrivate) "🔒 Private" else "🌐 Public"}"
        if (description.isNotBlank()) {
            binding.tvRepoDesc.text = description
            binding.tvRepoDesc.visibility = View.VISIBLE
        }

        // Tabs
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Files"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Branches"))
        binding.tabLayout.selectTab(binding.tabLayout.getTabAt(0))

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> {
                        binding.recyclerContents.visibility = View.VISIBLE
                        binding.recyclerBranches.visibility = View.GONE
                        binding.fabFileActions.visibility = View.VISIBLE
                    }
                    1 -> {
                        binding.recyclerContents.visibility = View.GONE
                        binding.recyclerBranches.visibility = View.VISIBLE
                        binding.fabFileActions.visibility = View.GONE
                        loadBranches()
                    }
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        // Content adapter
        contentAdapter = ContentAdapter(
            onFileClick = { content -> showFileActionDialog(content) },
            onFolderClick = { content ->
                currentPath = content.path
                binding.tvPath.text = "📂 /$currentPath"
                loadContents()
            }
        )
        contentAdapter.onSelectionChanged = { updateFab() }
        binding.recyclerContents.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerContents.adapter = contentAdapter

        // Branch adapter
        branchAdapter = BranchAdapter(
            onDeleteClick = { branch -> confirmDeleteBranch(branch) },
            onRenameClick = { branch -> showRenameBranchDialog(branch) },
            onSetDefaultClick = { branch -> confirmSetDefaultBranch(branch) },
            onBranchClick = { branch ->
                currentBranch = branch.name
                branchAdapter.defaultBranch = currentBranch
                branchAdapter.notifyDataSetChanged()
                Toast.makeText(requireContext(), "Switched to ${branch.name}", Toast.LENGTH_SHORT).show()
                loadContents()
            }
        )
        binding.recyclerBranches.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerBranches.adapter = branchAdapter

        // Swipe to refresh
        binding.swipeRefresh.setOnRefreshListener { loadContents() }

        // FAB — context-aware
        binding.fabFileActions.setOnClickListener {
            if (contentAdapter.selectedItems.isNotEmpty()) showBulkActionsDialog()
            else showFileActionsMenu()
        }
        binding.btnUpFolder.setOnClickListener { goUpFolder() }

        // Back button: go up folder first, then pop back stack
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (contentAdapter.selectedItems.isNotEmpty()) {
                        contentAdapter.clearSelection()
                    } else if (currentPath.isNotEmpty()) {
                        goUpFolder()
                    } else {
                        isEnabled = false
                        requireActivity().onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            })

        loadContents()
    }

    private fun updateFab() {
        val sel = contentAdapter.selectedItems.size
        binding.fabFileActions.setImageResource(
            if (sel > 0) android.R.drawable.ic_menu_manage
            else android.R.drawable.ic_menu_add
        )
    }

    private fun showBulkActionsDialog() {
        val count = contentAdapter.selectedItems.size
        val items = arrayOf("Delete Selected ($count)", "Copy Selected to Repo",
            "Select All", "Deselect All")
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Bulk Actions: $count item(s)")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> confirmBulkDelete()
                    1 -> showBulkCopyDialog()
                    2 -> { contentAdapter.selectAll() }
                    3 -> { contentAdapter.clearSelection() }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirmBulkDelete() {
        val selected = contentAdapter.selectedItems.toList()
        val items = contentAdapter.currentList.filter { it.sha in selected }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete ${items.size} item(s)?")
            .setMessage("This will permanently delete: ${items.joinToString("\n") { it.name }}")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    var ok = 0
                    val errors = mutableListOf<String>()
                    for (item in items) {
                        val r = repo.deleteFileContent(owner, repoName, item.path, item.sha, currentBranch)
                        if (r.isSuccess) ok++
                        else errors.add("${item.name}: ${r.exceptionOrNull()?.message}")
                    }
                    contentAdapter.clearSelection()
                    if (errors.isNotEmpty()) {
                        Toast.makeText(requireContext(), "Deleted $ok, failed ${errors.size}", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(requireContext(), "Deleted $ok items", Toast.LENGTH_SHORT).show()
                    }
                    loadContents()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showBulkCopyDialog() {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0)
        }
        val etRepo = EditText(requireContext()).apply { hint = "Target repo (owner/repo)" }
        val etPath = EditText(requireContext()).apply { hint = "Target folder path (optional)" }
        layout.addView(etRepo); layout.addView(etPath)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Copy ${contentAdapter.selectedItems.size} item(s)")
            .setView(layout)
            .setPositiveButton("Copy") { _, _ ->
                val target = etRepo.text.toString().trim()
                val basePath = etPath.text.toString().trim()
                if (!target.contains("/")) { Toast.makeText(requireContext(), "Use owner/repo format", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                lifecycleScope.launch {
                    var ok = 0
                    val items = contentAdapter.currentList.filter { it.sha in contentAdapter.selectedItems }
                    for (item in items) {
                        val tp = if (basePath.isEmpty()) item.path else "$basePath/${item.name}"
                        val r = repo.copyFileToRepo(owner, repoName, item.path, target, tp, currentBranch)
                        if (r.isSuccess) ok++
                    }
                    contentAdapter.clearSelection()
                    Toast.makeText(requireContext(), "Copied $ok/${items.size}", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmSetDefaultBranch(branch: GitHubBranch) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Set '${branch.name}' as default?")
            .setMessage("This will make '${branch.name}' the default branch for $owner/$repoName.")
            .setPositiveButton("Set Default") { _, _ ->
                lifecycleScope.launch {
                    val r = repo.setDefaultBranch(owner, repoName, branch.name)
                    r.fold(
                        onSuccess = {
                            currentBranch = branch.name
                            branchAdapter.defaultBranch = branch.name
                            branchAdapter.notifyDataSetChanged()
                            Toast.makeText(requireContext(), "Default branch set to ${branch.name}", Toast.LENGTH_SHORT).show()
                            loadContents()
                        },
                        onFailure = { e -> Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show() }
                    )
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun goUpFolder() {
        if (currentPath.contains("/")) {
            currentPath = currentPath.substringBeforeLast("/")
        } else {
            currentPath = ""
        }
        binding.tvPath.text = if (currentPath.isEmpty()) "" else "📂 /$currentPath"
        loadContents()
    }

    private fun loadContents() {
        binding.progressContent.visibility = View.VISIBLE
        binding.tvPath.text = if (currentPath.isEmpty()) "📂 / (root)" else "📂 /$currentPath"
        lifecycleScope.launch {
            try {
                Toast.makeText(requireContext(), "Loading: $owner/$repoName [$currentBranch]...", Toast.LENGTH_SHORT).show()
                val result = repo.getContents(owner, repoName, currentPath, currentBranch)
                result.fold(
                    onSuccess = { items ->
                        contentItems = items
                        filterAndShowContents()
                        if (items.isEmpty()) {
                            Toast.makeText(requireContext(), "Empty directory (${currentBranch})", Toast.LENGTH_LONG).show()
                        }
                    },
                    onFailure = { e ->
                        Toast.makeText(requireContext(), "⚠ ${e.message}", Toast.LENGTH_LONG).show()
                    }
                )
            } catch (ex: Exception) {
                Toast.makeText(requireContext(), "💥 ${ex.message}", Toast.LENGTH_LONG).show()
            }
            binding.progressContent.visibility = View.GONE
        }
    }

    private fun filterAndShowContents() {
        val filtered = if (showHidden) contentItems
        else contentItems.filter { !it.name.startsWith(".") }
        contentAdapter.submitList(filtered)
    }

    private fun loadBranches() {
        binding.progressContent.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = repo.listBranches(owner, repoName)
            result.fold(
                onSuccess = { branchList ->
                    branches = branchList
                    branchAdapter.defaultBranch = currentBranch
                    branchAdapter.submitList(branchList)
                },
                onFailure = { e ->
                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            )
            binding.progressContent.visibility = View.GONE
        }
    }

    private fun showFileActionsMenu() {
        val hiddenLabel = if (showHidden) "🔽 Hide Hidden Files" else "🔼 Show Hidden Files"
        val items = arrayOf(
            "Add / Create File", "Create Folder", "Rename File/Folder",
            "Upload File", "Upload Folder", "Download as ZIP",
            "Create Branch", hiddenLabel
        )
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("File Actions")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showCreateFileDialog()
                    1 -> showCreateFolderDialog()
                    2 -> showRenameContentDialog()
                    3 -> filePicker.launch("*/*")
                    4 -> folderPicker.launch(null)
                    5 -> downloadRepoAsZip()
                    6 -> showCreateBranchDialog()
                    7 -> { showHidden = !showHidden; filterAndShowContents() }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCreateFileDialog() {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 0)
        }
        val etFileName = EditText(requireContext()).apply { hint = "File name (e.g. test.txt)" }
        val etContent = EditText(requireContext()).apply {
            hint = "File content"
            minLines = 4
        }
        layout.addView(etFileName)
        layout.addView(etContent)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Create New File")
            .setView(layout)
            .setPositiveButton("Create") { _, _ ->
                val fileName = etFileName.text.toString().trim()
                val content = etContent.text.toString()
                val filePath = if (currentPath.isEmpty()) fileName else "$currentPath/$fileName"
                val contentBase64 = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)
                lifecycleScope.launch {
                    val result = repo.createFile(owner, repoName, filePath,
                        "Create $fileName", contentBase64, currentBranch)
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(), "File created!", Toast.LENGTH_SHORT).show()
                            loadContents()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCreateFolderDialog() {
        val etName = EditText(requireContext()).apply { hint = "Folder name" }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Create Folder")
            .setView(etName)
            .setPositiveButton("Create") { _, _ ->
                val folderName = etName.text.toString().trim()
                val folderPath = if (currentPath.isEmpty()) folderName else "$currentPath/$folderName"
                // Create .gitkeep file to make the folder
                val contentBase64 = Base64.encodeToString("".toByteArray(), Base64.NO_WRAP)
                lifecycleScope.launch {
                    val result = repo.createFile(owner, repoName, "$folderPath/.gitkeep",
                        "Create folder $folderName", contentBase64, currentBranch)
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(), "Folder created!", Toast.LENGTH_SHORT).show()
                            loadContents()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRenameContentDialog() {
        if (contentItems.isEmpty()) {
            Toast.makeText(requireContext(), "No files to rename", Toast.LENGTH_SHORT).show()
            return
        }
        val names = contentItems.map { "${if (it.type == "dir") "📁" else "📄"} ${it.name}" }.toTypedArray()
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select to rename")
            .setItems(names) { _, which ->
                val selected = contentItems[which]
                val etNewName = EditText(requireContext()).apply {
                    setText(selected.name)
                    hint = "New name"
                }
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Rename '${selected.name}'")
                    .setView(etNewName)
                    .setPositiveButton("Rename") { _, _ ->
                        val newName = etNewName.text.toString().trim()
                        val oldPath = selected.path
                        val newPath = oldPath.substringBeforeLast("/")
                            .let { if (it.isEmpty()) newName else "$it/$newName" }
                        lifecycleScope.launch {
                            // Get current file content
                            val contentResult = repo.getContents(owner, repoName, oldPath, currentBranch)
                            contentResult.fold(
                                onSuccess = { items ->
                                    val item = items.firstOrNull() ?: return@fold
                                    val fileContent = item.content
                                    val encoding = item.encoding
                                    val sha = item.sha
                                    // Create new file with same content
                                    val actualContent = if (fileContent != null && encoding == "base64") {
                                        fileContent.replace("\n", "")
                                    } else ""
                                    val createResult = repo.createFile(
                                        owner, repoName, newPath,
                                        "Rename ${selected.name} to $newName",
                                        actualContent, currentBranch
                                    )
                                    createResult.fold(
                                        onSuccess = {
                                            // Delete old
                                            repo.deleteFileContent(owner, repoName, oldPath, sha, currentBranch)
                                            Toast.makeText(requireContext(), "Renamed!", Toast.LENGTH_SHORT).show()
                                            loadContents()
                                        },
                                        onFailure = { e ->
                                            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                    )
                                },
                                onFailure = { e ->
                                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun handleFileUpload(uri: Uri) {
        lifecycleScope.launch {
            try {
                val fileName = getFileNameFromUri(uri) ?: "uploaded_file"
                val filePath = if (currentPath.isEmpty()) fileName else "$currentPath/$fileName"
                val inputStream = requireContext().contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes() ?: return@launch
                val contentBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

                NotificationHelper.showProgressNotification(requireContext(),
                    "Uploading", fileName, 0)

                val result = repo.createFile(owner, repoName, filePath,
                    "Upload $fileName", contentBase64, currentBranch)

                NotificationHelper.cancelProgressNotification(requireContext())

                result.fold(
                    onSuccess = {
                        NotificationHelper.showCompleteNotification(requireContext(),
                            "Upload Complete", fileName)
                        Toast.makeText(requireContext(), "Uploaded: $fileName", Toast.LENGTH_SHORT).show()
                        loadContents()
                    },
                    onFailure = { e ->
                        Toast.makeText(requireContext(), "Upload error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                )
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleFolderUpload(uri: Uri) {
        // Persist permission so we can read files after activity restarts
        try {
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            requireContext().contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: Exception) {}

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val rootDoc = DocumentFile.fromTreeUri(requireContext(), uri)
                if (rootDoc == null) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(requireContext(), "Cannot access folder - try again", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }
                withContext(Dispatchers.Main) {
                    NotificationHelper.showProgressNotification(requireContext(),
                        "Uploading Folder", "Scanning files...", 0)
                }
                // Collect all files first
                val files = mutableListOf<Pair<String, DocumentFile>>()
                collectFiles(rootDoc, "", files)
                if (files.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        NotificationHelper.cancelProgressNotification(requireContext())
                        Toast.makeText(requireContext(), "No files found in folder", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }
                // Upload each file
                var ok = 0; var fail = 0
                for ((relPath, docFile) in files) {
                    val fullPath = if (currentPath.isEmpty()) relPath else "$currentPath/$relPath"
                    val input = requireContext().contentResolver.openInputStream(docFile.uri)
                    val bytes = input?.readBytes()
                    input?.close()
                    if (bytes == null) { fail++; continue }
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val r = repo.createFile(owner, repoName, fullPath, "Upload $fullPath", b64, currentBranch)
                    if (r.isSuccess) ok++ else fail++
                    withContext(Dispatchers.Main) {
                        NotificationHelper.showProgressNotification(requireContext(),
                            "Uploading Folder", "$ok uploaded, $fail failed", ok, ok + fail + files.size)
                    }
                }
                withContext(Dispatchers.Main) {
                    NotificationHelper.cancelProgressNotification(requireContext())
                    NotificationHelper.showCompleteNotification(requireContext(),
                        "Upload Complete", "$ok files uploaded")
                    Toast.makeText(requireContext(), "Uploaded $ok files", Toast.LENGTH_SHORT).show()
                    loadContents()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    NotificationHelper.cancelProgressNotification(requireContext())
                    Toast.makeText(requireContext(), "Upload error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun collectFiles(folder: DocumentFile, prefix: String, out: MutableList<Pair<String, DocumentFile>>) {
        val children = folder.listFiles()
        for (child in children) {
            if (child.isDirectory) {
                collectFiles(child, if (prefix.isEmpty()) child.name!! else "$prefix/${child.name}", out)
            } else if (child.isFile) {
                val path = if (prefix.isEmpty()) child.name!! else "$prefix/${child.name}"
                out.add(path to child)
            }
        }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) it.getString(nameIndex) else null
            } else null
        }
    }

    private fun downloadRepoAsZip() {
        lifecycleScope.launch {
            try {
                NotificationHelper.showProgressNotification(requireContext(),
                    "Downloading", "$owner/$repoName", 0, 100)

                val result = repo.downloadRepoZip(owner, repoName, currentBranch)
                result.fold(
                    onSuccess = { body ->
                        withContext(Dispatchers.IO) {
                            val downloadsDir = FileUtils.getDownloadsDir(requireContext())
                            val zipFile = File(downloadsDir, "${repoName}_${currentBranch}.zip")
                            FileUtils.writeFile(zipFile, body.bytes())

                            withContext(Dispatchers.Main) {
                                NotificationHelper.cancelProgressNotification(requireContext())
                                NotificationHelper.showCompleteNotification(requireContext(),
                                    "Download Complete", "$repoName.zip")

                                // Offer to share
                                val zipUri = FileProvider.getUriForFile(requireContext(),
                                    "${requireContext().packageName}.fileprovider", zipFile)
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/zip"
                                    putExtra(Intent.EXTRA_STREAM, zipUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                startActivity(Intent.createChooser(shareIntent, "Share ZIP"))
                            }
                        }
                    },
                    onFailure = { e ->
                        NotificationHelper.cancelProgressNotification(requireContext())
                        Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                )
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showCreateBranchDialog() {
        val etName = EditText(requireContext()).apply { hint = "New branch name" }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Create Branch")
            .setMessage("Branch from: $currentBranch")
            .setView(etName)
            .setPositiveButton("Create") { _, _ ->
                val branchName = etName.text.toString().trim()
                if (branchName.isBlank()) return@setPositiveButton
                lifecycleScope.launch {
                    val refResult = repo.getContents(owner, repoName, "", currentBranch)
                    // Get SHA of current branch's latest commit via branches
                    val branchesResult = repo.listBranches(owner, repoName)
                    branchesResult.fold(
                        onSuccess = { branches ->
                            val currentBranchObj = branches.find { it.name == currentBranch }
                            if (currentBranchObj != null) {
                                val createResult = repo.createBranch(
                                    owner, repoName, branchName, currentBranchObj.commit.sha
                                )
                                createResult.fold(
                                    onSuccess = {
                                        Toast.makeText(requireContext(),
                                            "Branch '$branchName' created!", Toast.LENGTH_SHORT).show()
                                        loadBranches()
                                    },
                                    onFailure = { e ->
                                        Toast.makeText(requireContext(),
                                            "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(),
                                "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteBranch(branch: GitHubBranch) {
        if (branch.name == currentBranch) {
            Toast.makeText(requireContext(),
                "Cannot delete the default branch", Toast.LENGTH_SHORT).show()
            return
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Branch")
            .setMessage("Delete branch '${branch.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    val result = repo.deleteBranch(owner, repoName, branch.name)
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(),
                                "Branch deleted", Toast.LENGTH_SHORT).show()
                            loadBranches()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(),
                                "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRenameBranchDialog(branch: GitHubBranch) {
        val etNewName = EditText(requireContext()).apply {
            setText(branch.name)
            hint = "New branch name"
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Rename '${branch.name}'")
            .setView(etNewName)
            .setPositiveButton("Rename") { _, _ ->
                val newName = etNewName.text.toString().trim()
                if (newName.isBlank()) return@setPositiveButton
                lifecycleScope.launch {
                    val result = repo.renameBranch(owner, repoName, branch.name, newName)
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(),
                                "Renamed to '$newName'", Toast.LENGTH_SHORT).show()
                            loadBranches()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(),
                                "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFileActionDialog(content: GitHubContent) {
        val isDir = content.type == "dir"
        val items = if (isDir) {
            arrayOf("Open in Browser", "Delete Folder")
        } else {
            arrayOf("Open in Browser", "Edit File", "Copy Content to Clipboard", "Download", "Delete", "Copy to Another Repo")
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(content.name)
            .setItems(items) { _, which ->
                if (isDir) {
                    when (which) {
                        0 -> openInBrowser(content.htmlUrl)
                        1 -> confirmDeleteFile(content)
                    }
                } else {
                    when (which) {
                        0 -> openInBrowser(content.htmlUrl)
                        1 -> showEditFileDialog(content)
                        2 -> copyContentToClipboard(content)
                        3 -> downloadFile(content)
                        4 -> confirmDeleteFile(content)
                        5 -> showCopyToRepoDialog(content)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openInBrowser(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun copyContentToClipboard(content: GitHubContent) {
        lifecycleScope.launch {
            try {
                val result = repo.getFileContent(owner, repoName, content.path, currentBranch)
                result.fold(
                    onSuccess = { file ->
                        val text = if (file.content != null && file.encoding == "base64") {
                            Base64.decode(file.content.replace("\n", ""), Base64.DEFAULT).decodeToString()
                        } else {
                            file.content ?: ""
                        }
                        val cm = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText(content.name, text))
                        Toast.makeText(requireContext(), "Content copied!", Toast.LENGTH_SHORT).show()
                    },
                    onFailure = { e ->
                        Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                )
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEditFileDialog(content: GitHubContent) {
        lifecycleScope.launch {
            try {
                val result = repo.getFileContent(owner, repoName, content.path, currentBranch)
                result.fold(
                    onSuccess = { file ->
                        val currentText = if (file.content != null && file.encoding == "base64") {
                            Base64.decode(file.content.replace("\n", ""), Base64.DEFAULT).decodeToString()
                        } else ""
                        val layout = LinearLayout(requireContext()).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(40, 20, 40, 0)
                        }
                        val etContent = EditText(requireContext()).apply {
                            setText(currentText)
                            minLines = 10
                            gravity = android.view.Gravity.TOP
                        }
                        layout.addView(etContent)
                        MaterialAlertDialogBuilder(requireContext())
                            .setTitle("Edit: ${content.name}")
                            .setView(layout)
                            .setPositiveButton("Save") { _, _ ->
                                val newText = etContent.text.toString()
                                val newBase64 = Base64.encodeToString(newText.toByteArray(), Base64.NO_WRAP)
                                lifecycleScope.launch {
                                    val updResult = repo.updateFile(owner, repoName, content.path,
                                        "Update ${content.name}", newBase64, content.sha, currentBranch)
                                    updResult.fold(
                                        onSuccess = {
                                            Toast.makeText(requireContext(), "File saved!", Toast.LENGTH_SHORT).show()
                                            loadContents()
                                        },
                                        onFailure = { e ->
                                            Toast.makeText(requireContext(), "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                    )
                                }
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    },
                    onFailure = { e ->
                        Toast.makeText(requireContext(), "Cannot open file: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                )
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showCopyToRepoDialog(content: GitHubContent) {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 0)
        }
        val etTargetRepo = EditText(requireContext()).apply {
            hint = "Target repo (e.g. Samo1408/MyRepo)"
        }
        val etTargetPath = EditText(requireContext()).apply {
            hint = "Target path (e.g. docs/${content.name})"
            setText(content.name)
        }
        layout.addView(etTargetRepo)
        layout.addView(etTargetPath)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Copy '${content.name}' to...")
            .setView(layout)
            .setPositiveButton("Copy") { _, _ ->
                val targetRepo = etTargetRepo.text.toString().trim()
                val targetPath = etTargetPath.text.toString().trim()
                if (targetRepo.isBlank() || targetPath.isBlank()) {
                    Toast.makeText(requireContext(), "Fill both fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    val result = repo.copyFileToRepo(
                        owner, repoName, content.path, targetRepo, targetPath, currentBranch
                    )
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(), "Copied to $targetRepo/$targetPath!", Toast.LENGTH_SHORT).show()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(), "Copy failed: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteFile(content: GitHubContent) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete '${content.name}'?")
            .setMessage("This will delete the file from the repository.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    val result = repo.deleteFileContent(
                        owner, repoName, content.path, content.sha, currentBranch
                    )
                    result.fold(
                        onSuccess = {
                            Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_SHORT).show()
                            loadContents()
                        },
                        onFailure = { e ->
                            Toast.makeText(requireContext(),
                                "Error: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun downloadFile(content: GitHubContent) {
        val downloadUrl = content.downloadUrl
        if (downloadUrl == null) {
            Toast.makeText(requireContext(), "Cannot download this file", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                NotificationHelper.showProgressNotification(requireContext(),
                    "Downloading", content.name, 0)
                // Use okhttp directly for download
                val client = okhttp3.OkHttpClient()
                val request = okhttp3.Request.Builder()
                    .url(downloadUrl)
                    .addHeader("Authorization", "Bearer ${com.github.samo1408.myrepo.data.remote.GitHubClient.getToken()}")
                    .build()
                val response = withContext(Dispatchers.IO) {
                    client.newCall(request).execute()
                }
                if (response.isSuccessful) {
                    val bytes = response.body?.bytes() ?: return@launch
                    val downloadsDir = FileUtils.getDownloadsDir(requireContext())
                    val file = File(downloadsDir, content.name)
                    withContext(Dispatchers.IO) {
                        FileUtils.writeFile(file, bytes)
                    }
                    NotificationHelper.cancelProgressNotification(requireContext())
                    NotificationHelper.showCompleteNotification(requireContext(),
                        "Download Complete", content.name)
                    Toast.makeText(requireContext(),
                        "Downloaded: ${content.name}", Toast.LENGTH_SHORT).show()
                } else {
                    NotificationHelper.cancelProgressNotification(requireContext())
                    Toast.makeText(requireContext(),
                        "Download failed: ${response.code}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                NotificationHelper.cancelProgressNotification(requireContext())
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
